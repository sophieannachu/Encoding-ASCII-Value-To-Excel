﻿using System;
using System.Configuration;
using System.IO;
using System.Text;
using OfficeOpenXml;

namespace ConsoleApp
{
    class Program
    {
        static void Main(string[] args)
        {
            // 從app.config中讀取二進制字節串
            string bytesString = ConfigurationManager.AppSettings["bytesString"];

            // 將字節串轉換為ASCII編碼
            byte[] binaryData = Encoding.ASCII.GetBytes(bytesString);

            // 建立Excel檔案
            string outputPath = @"C:\tmp\mail.xls";
            FileInfo excelFile = new FileInfo(outputPath);
            ExcelPackage.LicenseContext = LicenseContext.NonCommercial;
            using (ExcelPackage package = new ExcelPackage())
            {
                ExcelWorksheet worksheet = package.Workbook.Worksheets.Add("Sheet1");

                // 寫入資料
                worksheet.Cells["A1"].Value = binaryData;

                // 將ExcelPackage寫入檔案
                package.SaveAs(excelFile);
            }

            Console.WriteLine("Excel檔案已成功產生並儲存到指定路徑。");
            Console.ReadLine();
        }
    }
}



